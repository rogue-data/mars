from django.apps import AppConfig


class MarsAppConfig(AppConfig):
    name = 'mars_app'
